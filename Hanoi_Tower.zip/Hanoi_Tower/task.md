# Towers of Hanoi Interactive Game

## Create a program that allows the user to play with a modified Towers of Hanoi.

### Requirements
- The submitted task is a self-solved task!
- The final version of the program must be functional. Compile and run!
- Code that does not compile is worth 0 points!
- Check the compilation with the `gcc -Wall` compiler before submission!
- Do not use global variables! Only macros are allowed!
- Strive for nice, clear coding, use indentation, avoid code repetition!
- The program should communicate! It should be clear to the user what the program expects and what exactly is happening!
- Structure the solution logically (use functions, separate translation units)!
- Do not allocate unnecessary memory and avoid memory leaks!
- Avoid statements that cause undefined behavior!
- Where a part of the task is not described exactly, we leave it up to you to implement it individually.
- When passing structures as parameters, consider where it is worth using a pointer!
- In the final program, unfulfilled expectations will result in a point deduction!

---

### Task
There are three towers and N pieces of disks in the game. Each disk has a different size, and their value is an element of the set {1, 2, ... , N}. At the beginning of the game, all the disks are on the first tower, randomly distributed - i.e. deviating from the original task, where the disks are in increasing order of size.

The player's task is to place the disks in increasing order on any tower of your choice.

---

### Programming Guidelines
The game can end in two ways:
- The player quits by entering a dedicated character.
- The player successfully places the discs in ascending order on one of the towers.

When starting the program, write the short "usage guide" of the game, its goal and the methods of control. The simplest way to index the towers is recommended with positive integers. However, when reading, you must also be able to interpret the character used to end the game!

The following description also includes the scoring system. We can assume that the user has no bad intentions and provides input that matches the type of data requested as input.

---

### Main program - 9 points
- Control center: provides infinite running, calls other functions and handles their feedback, manages resources.
- Hint: do not write an exit function, the main program handles exit - thus freeing up resources.
- In fact, the number of discs N represents the size of the towers. The user can set it in two ways:
  - During program startup, i.e. in the argument list of the main function. Then start the program, for example:
    ```
    ./hanoi 5
    ```
  - With `scanf()` after startup.
- You can use the resulting integer to dynamically size the towers.

---

### Generation - 3 points
- It is worth initializing the second and third towers to 0.
- And fill the first tower with random number generation, with values between 1 and N.
- Each number can appear once!

---

### Drawing - 7 points
Two solutions are suggested, one worth fewer points but simpler and one more difficult:
- Printing numbers representing the size of the disks (4 points).
- Using a number of special characters corresponding to the size of the disks (7 points). The towers can be drawn under or besides each other.

---

### Moving + Checking - 9 points
- We ask the user for the index of the two towers, i.e. from where and to where they move the disk.
- Pay attention to the special cases: moving from an empty tower, moving to a full tower.
- Of course, a larger disk cannot be placed on a smaller disk!
- After moving, you must check whether the disks are ordered in one of the towers.

---

### Modularization - 2 points
- There should be two source files and one header file.
